curses_squared by DragonDePlatino

Recommended minimum resolutions:
curses_vector_8x12		640x300		(VGA)
curses_vector_12x18		960x450		(qHD)
curses_vector_16x24		1280x600 	(HD, 720p)
curses_vector_24x36		1920x900 	(FHD, 1080p)
curses_vector_32x48		2560x1200	(QHD, 1440p)
curses_vector_40x60		3200x1500	(weirdos)
curses_vector_48x72		3840x1800	(UHD, 4K)

This work has been released under a CC0 license:
https://creativecommons.org/publicdomain/zero/1.0/legalcode